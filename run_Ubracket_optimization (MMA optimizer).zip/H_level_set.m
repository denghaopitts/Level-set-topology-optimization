function y=H_level_set(x)
delta=0.5;
alpha=1e-4;
index0=(x<-0.5);
index1=find((x>=-0.5).*(x<=0.5));
index2=(x>0.5);
y=zeros(size(x));
y(index0)=alpha;
y(index1)=3*(1-alpha)/4*(x(index1)/delta-x(index1).^3/(3*delta^3))+(1+alpha)/2;
y(index2)=1;