% Initialization
clc; clear; close('all');
nx = 200; ny = 200; % Mesh size
Phi = level_set_initialization(nx, ny, 11); % Initialize level set function
volfrac = 0.1; % Volume fraction constraint
[Vn, Vn_old1, Vn_old2] = deal(zeros([ny, nx])); % Design variables & sensitivity
[Vn_max, upperBound, lowerBound] = deal(0.1); % Design variable bounds & asymptote in GCMMA
[X, T] = generate_biclamped(nx, ny, 1, false); % Generate biclamped design mesh
Iter = 1; raa0 = 0.0001; raa = 0.0001; % Initial iteration and parameters for GCMMA

% Main loop for optimization
while (Iter < 1000)
    % Compute constraints and sensitivities; v is volume fraction, s is
    % p-norm von-Mises stress constraint. dv and ds is corresponding
    % sensitivity
    [v,dv,s,ds]=pstress_level(Phi,nx,ny,X,T);
    drho_dv = level_set_vd(Phi);
    ds_dvelocity = ds .* drho_dv;
    dv_dvelocity = dv .* drho_dv;

    % Call GCMMA to update design variables
    [Vn0, lowerBound, upperBound, raa0, raa] = gcmma_solver(1, nx*ny, Iter, Vn(:), -Vn_max, Vn_max, Vn_old1(:), Vn_old2(:), ...
        v, dv_dvelocity(:), s, ds_dvelocity(:)', lowerBound, upperBound, 1, 0, 1e4, 0, raa0, raa);
    
    % Update design variables
    Vn_old2 = Vn_old1; Vn_old1 = Vn; Vn = reshape(Vn0, [ny, nx]);

    % Evolve level set function based on updated design variables
    Phi = Evol_rein(Phi, Vn, 0, 120, Vn_max / 10); Iter = Iter + 1;

    % Plot level set function and surface plot
    density=flipud(imgaussfilt(Phi, 0.6));
    figure(1); contourf([density,fliplr(density)], [0 0]); colormap([0 0 0]); axis equal off;
    figure(2); surf(Phi, 'EdgeColor', 'none'); colormap('jet'); axis equal; axis off; drawnow;
    % Print iteration info
    fprintf('Iteration: %4i, Stress Constraint: %6.3f, Volume Fraction: %6.3f\n', Iter, s, v);
end







