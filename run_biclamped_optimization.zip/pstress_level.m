function [v,dv,s,ds]=pstress_level(Phi,nelx,nely,X,T)
xPhys=H_level_set(Phi);
penal=1;
%% OBJECTIVE FUNCTION AND SENSITIVITY ANALYSIS
[appSmax1,dsig,~,~]=Vpnorm(xPhys(:),nelx,nely,penal,X,T);
s=appSmax1-0.25;
ds=reshape(dsig,nely,nelx);
dv = ones(nely,nelx)/(nelx*nely);
v=mean(xPhys(:));