% Initialization
clc; clear; close('all');
nx = 200; ny = 200; % Mesh size
Phi = level_set_initialization(nx, ny, 11); % Initialize level set function
LSgrid = [ny, nx]; % Level set grid
Iter = 1; raa0 = 0.0001; raa = 0.0001; % Initial iteration and parameters for GCMMA
[Vn,Vn_old1,Vn_old2] = deal(zeros(LSgrid)); % Design variables and sensitivity
[Vn_max, upp, low] = deal(0.1, 0.1, -0.1); % Design variable bounds and asymptote in MMA
[X,T,i_img,j_img,xyelemout,elemlist] = generate_lbracket(nx,ny,1,false); % Generate L-bracket mesh
Phi(xyelemout) = -3; % Set passive element
[Phi] = level_rein(Phi,1000,0.1);  % Reinitialize level set function
Phi_his = zeros(numel(Phi), 2000); % History of Phi for each iteration
%Obtain the loading element index
solids = find(T(:,5)==2); 
padding = find(T(:,6)==1); 
solids_pad = intersect(solids,padding); 
loadedelem = setdiff(solids,solids_pad);
xyelemin=setdiff(1:nx*ny,xyelemout)';
loadedelem_ind=xyelemin(loadedelem);
% Main loop for optimization
while (Iter < 1000)
    % Compute constraints and sensitivities
    [v,dv,s,ds] = pstress_level_S(Phi,nx,ny,X,T,xyelemout);
    drho_dv = level_set_vd(Phi);
    ds_dvelocity = ds .* drho_dv;
    dv_dvelocity = dv .* drho_dv;
    % s is stress constraint, v is volume fraction, and dv, ds are
    % sensitivities
    % Call GCMMA to update design variables
    [Vn0,low,upp,raa0,raa] = gcmma_solver(1, prod(LSgrid), Iter, Vn(:), -Vn_max, Vn_max, Vn_old1(:), Vn_old2(:), v, dv_dvelocity(:), s, ds_dvelocity(:)', low, upp, 1, 0, 1e4, 0, raa0, raa);
    
    % Update design variables
    Vn_old2 = Vn_old1; Vn_old1 = Vn; Vn = reshape(Vn0, LSgrid);

    % Evolve level set function based on updated design variables
    Phi = Evol_rein(Phi, Vn, 0, 120, Vn_max / 10);  Iter = Iter + 1;

    % Plot level set function
    Phi0 = Phi; Phi0(loadedelem_ind) = 3; Phi0(xyelemout) = -3;
    figure(1); contourf(Phi0, [0 0]); colormap([0 0 0]); axis equal off;
    figure(2); surf(Phi0, 'EdgeColor', 'none'); colormap('jet'); axis equal; axis off; drawnow;

    % Print iteration info
    fprintf('It.: %4i  P-norm_cons.: %6.3f Volume_fraction.: %6.3f\n', Iter, s, v);
    
    % Store the current Phi
    Phi_his(:, Iter) = Phi0(:);
end