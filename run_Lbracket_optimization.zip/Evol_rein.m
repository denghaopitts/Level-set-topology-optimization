%% -------------------------Subfunctions----------------------------
function [Phi] = Evol_rein(Phi,Vn,kesi,re_num,dt_re) % H-J & reinit.
[Grad_P,Grad_M,Grad2,~] = Phi_Diff(Phi);
Phi = Phi+(max(Vn,0).*Grad_P+min(Vn,0).*Grad_M)+kesi*Grad2;
[~ ,~,~,S] = Phi_Diff(Phi);
for i = 1:re_num % Reinitialization
    [Grad_P ,Grad_M,~,~] = Phi_Diff(Phi);
    Phi = Phi-dt_re/max(abs(S(:))).*((max(S,0).*Grad_P+min(S,0).*Grad_M)-S);
end
%Phi = roundn(Phi,-6);