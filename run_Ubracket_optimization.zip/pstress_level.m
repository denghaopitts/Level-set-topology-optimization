function [v,dv,s,ds,VM]=pstress_level(Phi,nelx,nely,X,T)
xPhys=H_level_set(Phi);
penal=1;
%% OBJECTIVE FUNCTION AND SENSITIVITY ANALYSIS
[appSmax1,dsig,vol,dv,VM]=Vpnorm_d(xPhys(:),nelx,nely,penal,X,T);
s=appSmax1-1;
ds=dsig;
dv = ones(size(xPhys(:)))/(nelx*nely);
v=mean(xPhys(:));