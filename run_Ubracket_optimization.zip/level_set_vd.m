function drho_dv=level_set_vd(Phi)
drho_dv=delta_level_set(Phi);