function [appSmax,dsig,vol,dv,VM]=Vpnorm_d(x,sizex,sizey,penal,X,T)
%% MATERIAL PROPERTIES
Emax = 1;
Emin = Emax*1e-6;
nu = 0.3;
%% PREPARE DOMAIN
helem=1;
%--------------------------------------------------------------
%% PREPARE FINITE ELEMENT ANALYSIS
A11 = [12  3 -6 -3;  3 12  3  0; -6  3 12 -3; -3  0 -3 12];
A12 = [-6 -3  0  3; -3 -6 -3 -6;  0 -3 -6  3;  3 -6  3 -6];
B11 = [-4  3 -2  9;  3 -4 -9  4; -2 -9 -4 -3;  9  4 -3 -4];
B12 = [ 2 -3  4 -9; -3  2  9 -2;  4  9  2  3; -9 -2  3  2];
KE = 1/(1-nu^2)/24*([A11 A12;A12' A11]+nu*[B11 B12;B12' B11]);
nelem = size(T,1);
nodes = size(X,1);
ndof = 2*nodes;
edofMat = zeros(nelem,8);
edofMat(:,1:2) = [2*T(:,1)-1 2*T(:,1)];
edofMat(:,3:4) = [2*T(:,2)-1 2*T(:,2)];
edofMat(:,5:6) = [2*T(:,3)-1 2*T(:,3)];
edofMat(:,7:8) = [2*T(:,4)-1 2*T(:,4)];
iK = reshape(kron(edofMat,ones(8,1))',64*nelem,1);
jK = reshape(kron(edofMat,ones(1,8))',64*nelem,1);
% Prologation operators
U = zeros(ndof,1); LAM = 0*U;
Bmat = 1/helem*[-1/2 0 1/2 0 1/2 0 -1/2 0
0 -1/2 0 -1/2 0 1/2 0 1/2
-1/2 -1/2 -1/2 1/2 1/2 1/2 1/2 -1/2];
% The constitutive matrix
Dmat = 1/(1-nu^2)*[ 1 nu 0;nu 1 0;0 0 (1-nu)/2];
%--------------------------------------------------------------
%% DEFINE LOADS AND SUPPORTS
solids = find(T(:,5)==2); % Find solid elements
padding = find(T(:,6)==1); % Find padding elements
solids_pad = intersect(solids,padding); % Find padding solids
loadedelem = setdiff(solids,solids_pad);
nloadedelem = size(loadedelem,1);

loadeddof = edofMat(loadedelem,1:2:7);
loadeddof = loadeddof(:);
loadmag = -1; 
load_per_dof = loadmag/nloadedelem/4;
F = sparse(loadeddof,1,load_per_dof,ndof,1);
% Supports
% U-bracket
[supnodes,~] = find(X(:,1)==0); % Find nodes with x==0
supdofs = union(2*supnodes-1,2*supnodes);
alldofs = 1:ndof;
freedofs = setdiff(alldofs,supdofs);
% Null space elimination of supports
N = ones(ndof,1); N(supdofs,1) = 0; Null = spdiags(N,0,ndof,ndof);
x(T(:,5)==1) = 1e-6; % Voids
x(T(:,5)==2) = 1-1e-6; % Solids
x(loadedelem)=1;
xTilde = x;%(H*x)./Hs;
xPhys = xTilde;
sK = reshape(KE(:)*(Emin+xPhys(:)'.^penal*(Emax-Emin)),64*nelem,1);
K = sparse(iK,jK,sK);
K = (K+K')/2;
% For iterative stress calculation
stress_data.B = Bmat;
stress_data.D = Dmat;
stress_data.X = xPhys;
stress_data.EDOF = edofMat;
stress_data.E(1) = Emin;
stress_data.E(2) = Emax;
% Direct
U(freedofs) = K(freedofs,freedofs)\F(freedofs);
%% STRESS CONSTRAINT
% Evaluate stresses
[appSmax,~,~,~,ADJ,~,dsigvec] = getstress2d(nelem,U,xPhys,edofMat,Emin,Emax,nu,8,helem);
% Direct
LAM(freedofs) = K(freedofs,freedofs)\ADJ(freedofs);
ce1 = sum(LAM(edofMat)*KE.*U(edofMat),2); % Lam'*K*U
dsig1 = penal*(Emax-Emin)*xPhys.^(penal-1).*ce1; % Lam'*dKdrho*U
dsig2 = dsigvec; % dsigaggdrho
dsig = dsig2 + dsig1;
dv = ones(nelem,1)/nelem;
vol=mean(x(:));
UxPhys = U;   
xDilSharp=x;
STRAIN = UxPhys(edofMat)*Bmat';
STRESS = STRAIN*Dmat;
Emat = repmat(Emin+xDilSharp(:)*(Emax-Emin),1,3);
STRESS = STRESS.*Emat;
VM = STRESS(:,1).^2 - STRESS(:,1).*STRESS(:,2) + STRESS(:,2).^2 + 3*STRESS(:,3).^2;
VM = VM.^(0.5);
maxVMscaled = max(VM);