function Phi=level_set_initialization(nx,ny,xnum)
% nx=240;
% ny=200;
% xnum=10;
%[LSy,LSx] = ndgrid(-0.5:ny+0.5,-0.5:nx+0.5); % LS grid
[LSy,LSx] = ndgrid(0.5:ny,0.5:nx); % LS grid
[ynum,cr] = deal(max(floor(xnum/nx*ny),1),nx/xnum/4);
[cy,cx] = ndgrid((0:2:ynum*2)/(2*ynum/ny),(1:2:xnum*2+1)/(2*xnum/nx));
[cx,cy] = deal([cx(:);cx(:)-nx/xnum/2],[cy(:);cy(:)+ny/ynum/2]);
[fx,fy,fixed] = deal(nx/2+1,ny+1,[1,2,2*(ny+1)*nx+2]); % Boundary condition
cNAN = max(abs([cx-fx,cy-fy])-1,[],2)<=cr;  [cx(cNAN),cy(cNAN)] = deal(inf);
[cx,xt] = ndgrid(cx,LSx);  [cy,yt] = ndgrid(cy,LSy);
Phi = sqrt((xt-cx).^2+(yt-cy).^2)-cr; % Initial LS function
nod_n = [ny,nx]; 
LSgrid = nod_n; 
Phi = reshape(min([Phi;[LSx(:),nx-LSx(:),LSy(:),ny-LSy(:)]'+0.5]),LSgrid);
figure(1); contourf(Phi,[0 0]); colormap([0 0 0]); axis equal off;