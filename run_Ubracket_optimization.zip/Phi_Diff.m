function [Grad_P,Grad_M,Grad2,S] = Phi_Diff(Phi) % LS Gradient (upwind)
DxL = (Phi-[ Phi(:,1)*2-Phi(:,2),Phi(:,1:end-1)]);
DxR = ([Phi(:,2:end),Phi(:,end)*2-Phi(:,end-1)]-Phi);
DyL = (Phi-[Phi(1,:)*2-Phi(2,:);Phi(1:end-1,:)]);
DyR = ([Phi(2:end,:);Phi(end,:)*2-Phi(end-1, :)] - Phi);
Grad_P = sqrt(max(DxL,0).^2+min(DxR,0).^2+max(DyL,0).^2+min(DyR,0).^2);
Grad_M = sqrt(min(DxL,0).^2+max(DxR,0).^2+min(DyL,0).^2+max(DyR,0).^2);
[Phixx,Phiyy] = deal(DxR-DxL,DyR-DyL);   Grad2 = Phixx+Phiyy;
S = Phi./(sqrt(Phi.^2+(((DxL+DxR)/2).^2+((DyL+DyR)/2).^2))+eps); % sign(Phi)