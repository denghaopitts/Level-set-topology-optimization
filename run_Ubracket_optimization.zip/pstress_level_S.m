function [v,dv,s,ds]=pstress_level_S(Phi,nelx,nely,X,T,xyelemout)
Phi0=Phi(:);
Phi0(xyelemout)=[];
dv=zeros(nelx*nely,1);
ds=zeros(nelx*nely,1);
[v,dv0,s,ds0,VM]=pstress_level(Phi0,nelx,nely,X,T);
index=setdiff(1:nelx*nely,xyelemout);
dv(index)=dv0;
ds(index)=ds0;
dv=reshape(dv,nely,nelx);
ds=reshape(ds,nely,nelx);
VM_full=zeros(size(Phi(:)));
VM_full(setdiff(1:nelx*nely,xyelemout))=VM;
figure(3)
imagesc(flipud(reshape(VM_full,nely,nelx)));axis equal;axis off;colormap('jet');
% Get the maximum value of the data
max_val = max(VM_full(:));
min_val = min(VM_full(:));
% Create a colorbar, set the 'Ticks' property to include max value
colorbar('Ticks',[min_val , max_val],'FontSize',15); 
