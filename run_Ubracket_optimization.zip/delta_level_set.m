function  DeltaPhi=delta_level_set(Phi)
delta=0.5;
 indexDelta = (abs(Phi(:))<=delta);
 DeltaPhi = zeros(size(Phi));
 DeltaPhi(indexDelta) = 0.75/delta*(1-Phi(indexDelta).^2/delta^2);
